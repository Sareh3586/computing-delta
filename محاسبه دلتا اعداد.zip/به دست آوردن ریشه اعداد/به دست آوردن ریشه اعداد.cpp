#include <iostream>
#include <conio.h>
#include <math.h>
using namespace std;

class equation {

private:
	float a, b, c ,delta;
public:
	//constructor
	equation(float s,float j, float k)
	{
		a = s;
		b = j;
		c = k;
	}
	void  deltaclac();
	void  set();
}; 

void equation::deltaclac()
{
	delta = (b * b) - ((4) * (a * c));
}
void equation::set()
{ 
	if(delta > 0)
	{
	     int x1 = ((-b) + ((int)sqrt(delta))) / (2 * a);
	     int x2 = ((-b) - ((int)sqrt(delta))) / (2 * a);
	     cout << "javab:" <<endl<< x1 << endl << x2;
	}
	else if (delta == 0) {
	    int yek = ((-b) / (2 * a));
		cout << "javab:" << yek;
	}
	if (delta < 0)
	{
	    cout << "!!!!!Reyshe nadarim!!!!!";
	}
}
int main()
{
    float a, b, c, delta;
    cout << "enter a,b,c:";
    cin>>a >>b >>c;
    equation x(a,b,c);
    x .deltaclac();
    x.set();
    return 0;
}
